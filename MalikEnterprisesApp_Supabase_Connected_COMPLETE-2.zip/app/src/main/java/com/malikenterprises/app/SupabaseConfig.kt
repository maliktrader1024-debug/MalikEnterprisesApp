package com.malikenterprises.app

object SupabaseConfig {
    // Your Supabase project
    const val URL = "https://wlplvefzvwxjxuvjixmw.supabase.co"

    // Paste your Supabase Publishable Key here.
    // Never put the secret/service_role key in the Android app.
    const val PUBLISHABLE_KEY = "sb_publishable_yWSezn-ktigaxRJEA6bk7A_C1rmyRBN"
}
