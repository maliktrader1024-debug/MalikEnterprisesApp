MALIK ENTERPRISES ANDROID APP — SUPABASE CONNECTED

The Supabase project URL and publishable key are already embedded in:
app/src/main/java/com/malikenterprises/app/SupabaseConfig.kt

Supabase project URL:
https://wlplvefzvwxjxuvjixmw.supabase.co

IMPORTANT:
- The file name SupabaseConfig.kt is correct and must remain unchanged.
- The app uses the Supabase PUBLISHABLE key, not a secret/service_role key.
- Open the project folder in Android Studio and build the APK from Build > Build APK(s).

Project package:
com.malikenterprises.app
